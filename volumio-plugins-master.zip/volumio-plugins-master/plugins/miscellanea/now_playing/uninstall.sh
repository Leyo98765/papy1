#!/bin/bash
echo "Now Playing plugin uninstalled"
