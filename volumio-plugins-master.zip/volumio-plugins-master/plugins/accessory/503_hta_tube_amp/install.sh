#!/bin/bash

#requred to end the plugin install
echo "plugininstallend"
