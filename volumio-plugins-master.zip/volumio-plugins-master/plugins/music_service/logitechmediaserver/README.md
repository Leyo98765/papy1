# volumio-lms-plugin
Manage Logitech Media Server in Volumio

The button for the webconsole only works in Volumio 2.260 and up.
