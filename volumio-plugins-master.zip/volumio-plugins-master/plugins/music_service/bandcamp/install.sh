#!/bin/bash
echo "Bandcamp Discover plugin installed"
