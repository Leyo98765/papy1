# volumio 2 -plugins #
## Please, this Github repo is for Volumio2 and is no longer maintained
If you want to write a plugin for Volumio 3, please see https://developers.volumio.com/plugins/plugins-overview
